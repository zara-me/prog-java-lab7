package itmo.programming.client.commands;

import itmo.programming.client.manager.AskManager;
import itmo.programming.client.manager.AuthManager;
import itmo.programming.common.model.LabWork;
import itmo.programming.common.network.Request;
import itmo.programming.common.user.User;
import java.io.IOException;

/**
 * Команда remove_greater на клиенте.
 */
public class RemoveGreater implements Base {
    private final AskManager askManager;
    private final AuthManager authManager;

    /**
     * Конструктор.
     *
     * @param askManager askManager
     * @param authManager authManager
     */
    public RemoveGreater(AskManager askManager, AuthManager authManager) {
        this.askManager = askManager;
        this.authManager = authManager;
    }

    @Override
    public Request execute(String[] args) throws IOException {
        final LabWork labWork = askManager.askLabWork();
        final User currentUser = authManager.getCurrentUser();
        return new Request("remove_greater", args,
                labWork, currentUser, "client-" + System.currentTimeMillis());
    }
}



