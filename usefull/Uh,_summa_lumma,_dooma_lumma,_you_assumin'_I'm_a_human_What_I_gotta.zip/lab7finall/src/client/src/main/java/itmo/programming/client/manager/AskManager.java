package itmo.programming.client.manager;

import itmo.programming.common.model.Coordinates;
import itmo.programming.common.model.Difficulty;
import itmo.programming.common.model.Discipline;
import itmo.programming.common.model.LabWork;
import java.io.BufferedReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Класс, хранящий методы, запрашивающие значения полей LabWork у клиента.
 */
public class AskManager {
    private static final long MAX_X_COORDINATE = 677;
    private final BufferedReader reader;

    /**
     * Конструктор класса.
     *
     * @param reader reader.
     */
    public AskManager(BufferedReader reader) {
        this.reader = reader;
    }

    /**
     * Читает объект LabWork из консоли.
     *
     * @return объект LabWork
     * @throws IOException при ошибке чтения
     */
    public LabWork askLabWork() throws IOException {
        System.out.println("Введите LabWork:");

        // Чтение имени
        String name;
        while (true) {
            System.out.print("name (Поле не может быть null, Строка не может быть пустой): ");
            name = reader.readLine().trim();
            if (!name.isEmpty()) {
                break;
            }
            System.out.println("Ошибка: поле не может быть пустым");
        }

        // Чтение координат
        final Coordinates coordinates = askCoordinates();

        // Чтение minimalPoint
        int minimalPoint;
        while (true) {
            System.out.print("minimalPoint (Значение поля должно быть больше 0): ");
            try {
                minimalPoint = Integer.parseInt(reader.readLine().trim());
                if (minimalPoint > 0) {
                    break;
                }
                System.out.println("Ошибка: значение должно быть больше 0");
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите корректное число");
            }
        }

        // Чтение averagePoint
        double averagePoint;
        while (true) {
            System.out.print("averagePoint (Значение поля должно быть больше 0): ");
            try {
                averagePoint = Double.parseDouble(reader.readLine().trim());
                if (averagePoint > 0) {
                    break;
                }
                System.out.println("Ошибка: значение должно быть больше 0");
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите корректное число");
            }
        }

        // Чтение difficulty
        final Difficulty difficulty = askDifficulty();

        // Чтение дисциплины
        final Discipline discipline = askDiscipline();

        return new LabWork(
                0, // id будет установлен сервером
                name,
                coordinates,
                LocalDate.now(), // creationDate устанавливается автоматически
                minimalPoint,
                averagePoint,
                difficulty,
                discipline
        );
    }

    /**
     * Читает координаты из консоли.
     *
     * @return объект Coordinates
     * @throws IOException при ошибке чтения
     */
    private Coordinates askCoordinates() throws IOException {
        System.out.println("Введите координаты:");

        // Чтение x
        Long x;
        while (true) {
            System.out.print("x (Максимальное значение поля: 677, Поле не может быть null): ");
            try {
                x = Long.parseLong(reader.readLine().trim());
                if (x <= MAX_X_COORDINATE) {
                    break;
                }
                System.out.println("Ошибка: значение должно быть не больше " + MAX_X_COORDINATE);
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите корректное число");
            }
        }

        // Чтение y
        Long y;
        while (true) {
            System.out.print("y (Поле не может быть null): ");
            try {
                y = Long.parseLong(reader.readLine().trim());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите корректное число");
            }
        }

        return new Coordinates(x, y);
    }

    /**
     * Читает уровень сложности из консоли.
     *
     * @return объект Difficulty
     * @throws IOException при ошибке чтения
     */
    private Difficulty askDifficulty() throws IOException {
        System.out.println("Выберите Difficulty (может быть null):");
        System.out.println("0. null");
        final Difficulty[] difficulties = Difficulty.values();
        for (int i = 0; i < difficulties.length; i++) {
            System.out.println((i + 1) + ". " + difficulties[i]);
        }
        System.out.print("Введите номер либо же строку: ");
        while (true) {
            final String input = reader.readLine().trim();
            if (input.isEmpty() || input.equals("0")) {
                return null;
            }
            try {
                final int value = Integer.parseInt(input);
                if (value >= 1 && value <= difficulties.length) {
                    return difficulties[value - 1];
                } else {
                    System.out.println("Нет такого номера!");
                }
            } catch (NumberFormatException e) {
                for (Difficulty difficulty : difficulties) {
                    if (difficulty.toString().equals(input.toUpperCase())) {
                        return difficulty;
                    }
                }
                System.out.println("Нет такого значения Difficulty!");
            }
        }
    }

    /**
     * Читает информацию о дисциплине из консоли.
     *
     * @return объект Discipline
     * @throws IOException при ошибке чтения
     */
    private Discipline askDiscipline() throws IOException {
        System.out.println("Введите Discipline:");

        String name;
        while (true) {
            System.out.print("name (Поле не может быть null, Строка не может быть пустой): ");
            name = reader.readLine().trim();
            if (!name.isEmpty()) {
                break;
            }
            System.out.println("Ошибка: поле не может быть пустым");
        }

        int lectureHours;
        while (true) {
            System.out.print("lectureHours (количество лекционных часов): ");
            try {
                lectureHours = Integer.parseInt(reader.readLine().trim());
                break;
            } catch (NumberFormatException e) {
                System.out.println("Ошибка: введите корректное число");
            }
        }

        return new Discipline(name, lectureHours);
    }
}