package itmo.programming.server.commands;

import itmo.programming.common.model.LabWork;
import itmo.programming.common.network.Request;
import itmo.programming.common.network.Response;
import itmo.programming.server.manager.CollectionManager;
import java.util.List;

/**
 * Команда фильтрации элементов коллекции по полю name.
 */
public class FilterContainsNameCommand implements Command {
    private final CollectionManager collectionManager;

    /**
     * Создает новую команду фильтрации по имени.
     *
     * @param collectionManager менеджер коллекции
     */
    public FilterContainsNameCommand(CollectionManager collectionManager) {
        this.collectionManager = collectionManager;
    }

    /**
     * Выполняет команду фильтрации элементов по полю name.
     *
     * @param request запрос, содержащий строку для фильтрации
     * @return ответ с результатом выполнения команды
     */
    @Override
    public Response execute(Request request) {
        if (request.getArguments().length != 1) {
            return Response.error(
                "Использование: filter_contains_name <name>",
                "InvalidArgumentCount", null,
                request.getClientId()
            );
        }

        final String name = request.getArguments()[0];
        final List<LabWork> filtered = collectionManager.filterContainsName(name);

        if (filtered.isEmpty()) {
            return Response.ok(
                "Элементы с заданной подстрокой в поле name не найдены",
                filtered, null,
                request.getClientId()
            );
        } else {
            return Response.ok(
                "Найдены элементы с заданной подстрокой в поле name",
                filtered, null,
                request.getClientId()
            );
        }
    }

    /**
     * Возвращает описание команды.
     *
     * @return описание команды
     */
    @Override
    public String getDescription() {
        return "filter_contains_name name : "
                + "вывести элементы, значение поля name которых содержит заданную подстроку";
    }
}