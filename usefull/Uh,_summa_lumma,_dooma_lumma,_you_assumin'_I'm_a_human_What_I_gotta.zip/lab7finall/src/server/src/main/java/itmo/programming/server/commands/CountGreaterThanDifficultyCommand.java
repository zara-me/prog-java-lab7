package itmo.programming.server.commands;

import itmo.programming.common.network.Request;
import itmo.programming.common.network.Response;
import itmo.programming.server.manager.CollectionManager;

/**
 * Команда подсчета элементов с difficulty больше заданного.
 */
public class CountGreaterThanDifficultyCommand implements Command {
    private final CollectionManager collectionManager;

    /**
     * Создает новую команду подсчета элементов по difficulty.
     *
     * @param collectionManager менеджер коллекции
     */
    public CountGreaterThanDifficultyCommand(CollectionManager collectionManager) {
        this.collectionManager = collectionManager;
    }

    /**
     * Выполняет команду подсчета элементов с difficulty больше заданного.
     *
     * @param request запрос на выполнение команды
     * @return ответ с количеством элементов
     */
    @Override
    public Response execute(Request request) {
        if (request.getArguments().length != 1) {
            return Response.error(
                "Использование: count_greater_than_difficulty <difficulty>",
                "InvalidArgumentCount", null,
                request.getClientId()
            );
        }

        final String difficulty = request.getArguments()[0];
        final long count = collectionManager.countGreaterThanDifficulty(difficulty);
        
        return Response.ok(
            "Количество элементов с difficulty больше '" + difficulty + "': " + count,
            count, null,
            request.getClientId()
        );
    }

    @Override
    public String getDescription() {
        return "count_greater_than_difficulty difficulty : вывести количество элементов, значение поля difficulty которых больше заданного";
    }
}
