package itmo.programming.server.commands;

import itmo.programming.common.model.LabWork;
import itmo.programming.common.network.Request;
import itmo.programming.common.network.Response;
import itmo.programming.server.database.LabWorkDaO;
import itmo.programming.server.manager.CollectionManager;
import java.sql.SQLException;

/**
 * Команда обновления элемента коллекции по id.
 */
public class UpdateCommand implements Command {
    private final CollectionManager collectionManager;
    private final LabWorkDaO labWorkDaO;

    /**
     * Конструктор команды обновления.
     *
     * @param collectionManager менеджер коллекции
     */
    public UpdateCommand(CollectionManager collectionManager, LabWorkDaO labWorkDaO) {
        this.collectionManager = collectionManager;
        this.labWorkDaO = labWorkDaO;
    }

    @Override
    public Response execute(Request request) {
        if (request.getData().equals("check")) {
            if (request.getArguments().length == 1) {
                final Integer id = Integer.parseInt(request.getArguments()[0]);
                if (collectionManager.existsById(id)) {
                    final String owner = request.getUser().getUsername();
                    if (!collectionManager.checkOwner(id, owner)) {
                        return Response.error("anotherOwner", null, null, request.getClientId());
                    }
                    return Response.ok("exist", null, null, request.getClientId());
                } else {
                    return Response.error("notExist", null, null, request.getClientId());
                }
            }
        }

        if (request.getArguments().length != 1) {
            return Response.error(
                "Использование: update <id>",
                "InvalidArgumentCount", null,
                request.getClientId()
            );
        }

        try {
            final int id = Integer.parseInt(request.getArguments()[0]);
            final LabWork labWork = (LabWork) request.getData();

            if (labWork == null) {
                return Response.error(
                    "Данные для обновления отсутствуют",
                    "NullLabWork", null,
                    request.getClientId()
                );
            } else {
                final String owner = request.getUser().getUsername();
                final boolean updated = labWorkDaO.update(id, labWork, owner);
                if (!updated) {
                    return Response.error("Не удалось обновить элемент в базе данных",
                            null, null, request.getClientId());
                }
                final boolean exists = collectionManager.updateById(id,
                        labWork, request.getUser().getUsername());
                if (exists) {
                    return Response.ok(
                        "Элемент успешно обновлен",
                        null, null,
                        request.getClientId()
                    );
                } else {
                    return Response.error(
                        "Элемент с id " + id + " не найден",
                        "ElementNotFound", null,
                        request.getClientId()
                    );
                }
            }
        } catch (NumberFormatException e) {
            return Response.error(
                "id должен быть числом",
                "InvalidIdFormat", null,
                request.getClientId()
            );
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Возвращает описание команды.
     *
     * @return описание команды
     */
    @Override
    public String getDescription() {
        return "update id {element} : обновить значение элемента коллекции по id";
    }
}
