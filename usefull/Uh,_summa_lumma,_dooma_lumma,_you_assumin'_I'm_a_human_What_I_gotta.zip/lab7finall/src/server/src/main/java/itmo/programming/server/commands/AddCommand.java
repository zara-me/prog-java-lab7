package itmo.programming.server.commands;

import itmo.programming.common.model.LabWork;
import itmo.programming.common.network.Request;
import itmo.programming.common.network.Response;
import itmo.programming.server.database.LabWorkDaO;
import itmo.programming.server.manager.CollectionManager;
import java.sql.SQLException;

/**
 * Команда добавления нового элемента в коллекцию.
 */
public class AddCommand implements Command {
    private final CollectionManager collectionManager;
    private final LabWorkDaO labWorkDaO;


    /**
     * Создает новую команду добавления.
     *
     * @param collectionManager менеджер коллекции
     */
    public AddCommand(CollectionManager collectionManager, LabWorkDaO labWorkDaO) {
        this.collectionManager = collectionManager;
        this.labWorkDaO = labWorkDaO;
    }

    /**
     * Выполняет команду добавления элемента.
     *
     * @param request запрос, содержащий данные для добавления
     * @return ответ с результатом выполнения команды
     */
    @Override
    public Response execute(Request request) {
        try {
            System.out.println("=== ВЫПОЛНЕНИЕ КОМАНДЫ ADD ===");
            System.out.println("Пользователь: " + (request.getUser() != null ? request.getUser().getUsername() : "null"));
            System.out.println("Данные: " + (request.getData() != null ? "не null" : "null"));
            
            final LabWork labWork = (LabWork) request.getData();
            final String username = request.getUser().getUsername();
            System.out.println("Начинаем вставку в базу данных...");
            final int generatedId = labWorkDaO.insert(labWork, username);
            labWork.setId(generatedId);
            labWork.setOwner(username);

            synchronized (collectionManager) { // Синхронизованно добавляем в коллекцию
                collectionManager.add(labWork, username);
            }
            return Response.ok("Элемент успешно добавлен (id = " + generatedId + ").",
                    null, null, request.getClientId());
        } catch (SQLException e) {
            System.out.println("=== ОШИБКА SQL ===");
            System.out.println("Сообщение: " + e.getMessage());
            e.printStackTrace();
            
            String errorMessage = "Ошибка при добавлении элемента: " + e.getMessage();
            if (e.getMessage().contains("не существует в базе данных")) {
                errorMessage = "Ошибка: Пользователь не авторизован или не существует. Пожалуйста, сначала войдите в систему (команда login) или зарегистрируйтесь (команда register).";
            } else if (e.getMessage().contains("foreign key constraint")) {
                errorMessage = "Ошибка: Пользователь не авторизован. Пожалуйста, сначала войдите в систему (команда login) или зарегистрируйтесь (команда register).";
            }
            return Response.error(errorMessage,
                    null, null, request.getClientId());
        } catch (NullPointerException e) {
            System.out.println("=== ОШИБКА NULL POINTER ===");
            e.printStackTrace();
            return Response.error("Невозможно добавить пустой элемент!",
                    null, null, request.getClientId());
        } catch (Exception e) {
            System.out.println("=== НЕОЖИДАННАЯ ОШИБКА ===");
            System.out.println("Тип: " + e.getClass().getSimpleName());
            System.out.println("Сообщение: " + e.getMessage());
            e.printStackTrace();
            return Response.error("Неожиданная ошибка: " + e.getMessage(),
                    null, null, request.getClientId());
        }


    }

    /**
     * Возвращает описание команды.
     *
     * @return описание команды
     */
    @Override
    public String getDescription() {
        return "add {element} : добавить новый элемент в коллекцию";
    }
}
