package itmo.programming.server.manager;


import itmo.programming.common.model.LabWork;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.TreeSet;
import java.util.stream.Collectors;

/**
 * Менеджер коллекции на сервере.
 */
public class CollectionManager {
    private TreeSet<LabWork> collection;
    private final Date initializationDate;

    /**
     * Создает новый менеджер коллекции.
     * Инициализирует пустую коллекцию и настраивает сериализацию.
     */
    public CollectionManager() {
        this.collection = new TreeSet<>();
        this.initializationDate = new Date();
    }

    /**
     * Заменяет текущую коллекцию на новую.
     *
     * @param newCollection новая коллекция LabWork
     */
    public void setCollection(TreeSet<LabWork> newCollection) {
        collection.clear();
        collection.addAll(newCollection);
    }

    /**
     * Возвращает копию текущей коллекции.
     *
     * @return копия TreeSet с элементами коллекции
     */
    public synchronized TreeSet<LabWork> getCollection() {
        return new TreeSet<>(collection);
    }

    /**
     * Добавляет новую LabWork в коллекцию.
     *
     * @param labWork добавляемый объект
     * @return true, если объект успешно добавлен
     */
    public synchronized boolean add(LabWork labWork, String username) {
        if (labWork == null) {
            return false;
        }
        labWork.setOwner(username);
        return collection.add(labWork);
    }

    /**
     * Удаляет все элементы, принадлежащие указанному пользователю.
     *
     * @param owner имя владельца
     */
    public synchronized void clear(String owner) {
        collection.removeIf(labWork -> owner.equals(labWork.getOwner()));
    }

    /**
     * Удаляет объект по id, если он принадлежит указанному пользователю.
     *
     * @param id идентификатор объекта
     * @param owner имя владельца
     * @return true, если объект был удалён
     */
    public synchronized boolean removeById(Integer id, String owner) {
        return collection.removeIf(labWork -> {
            if (labWork.getId() != id) {
                return false;
            }
            return owner.equals(labWork.getOwner());
        });
    }

    /**
     * Обновляет объект по id, если он принадлежит указанному пользователю.
     *
     * @param id идентификатор объекта
     * @param newLabWork новый объект
     * @param owner имя владельца
     * @return true, если обновление успешно
     */
    public synchronized boolean updateById(Integer id, LabWork newLabWork, String owner) {
        final Optional<LabWork> target = collection.stream()
                .filter(l -> {
                    if (l.getId() != id) {
                        return false;
                    }
                    return owner.equals(l.getOwner());
                })
                .findFirst();

        if (target.isPresent()) {
            collection.remove(target.get());
            newLabWork.setId(id);
            newLabWork.setOwner(owner);
            return collection.add(newLabWork);
        }
        return false;
    }

    /**
     * Добавляет объект, если он больше текущего максимального в коллекции.
     *
     * @param labWork объект для добавления
     * @return true, если добавление выполнено
     */
    public synchronized boolean addIfMax(LabWork labWork) {
        return collection.isEmpty() || labWork.compareTo(
                collection.last()) > 0;
    }

    /**
     * Добавляет объект, если он меньше текущего минимального в коллекции.
     *
     * @param labWork объект для добавления
     * @return true, если добавление выполнено
     */
    public synchronized boolean addIfMin(LabWork labWork) {
        if (collection.isEmpty()) {
            return collection.add(labWork);
        }
        if (labWork.compareTo(collection.first()) < 0) {
            return collection.add(labWork);
        }
        return false;
    }

    /**
     * Вычисляет среднее значение поля averagePoint в коллекции.
     *
     * @return среднее значение averagePoint
     */
    public synchronized double averageOfAveragePoint() {
        return collection.stream().mapToDouble(LabWork::getAveragePoint).average().orElse(0.0);
    }

    /**
     * Возвращает количество элементов, значение поля difficulty которых больше заданного.
     *
     * @param difficulty значение поля difficulty для сравнения
     * @return количество подходящих элементов
     */
    public synchronized long countGreaterThanDifficulty(String difficulty) {
        return collection.stream()
                .filter(l -> {
                    if (l.getDifficulty() == null) {
                        return false;
                    }
                    return l.getDifficulty().name().compareTo(difficulty) > 0;
                })
                .count();
    }

    /**
     * Возвращает список элементов, значение поля name которых содержит заданную подстроку.
     *
     * @param name подстрока для поиска в поле name
     * @return список подходящих элементов
     */
    public synchronized List<LabWork> filterContainsName(String name) {
        return collection.stream()
                .filter(l -> {
                    if (l.getName() == null) {
                        return false;
                    }
                    return l.getName().contains(name);
                })
                .collect(Collectors.toList());
    }

    /**
     * Возвращает список элементов в порядке возрастания.
     *
     * @return отсортированный список элементов
     */
    public synchronized List<LabWork> getAscending() {
        return collection.stream()
                .sorted()
                .collect(Collectors.toList());
    }

    /**
     * Возвращает информацию о текущей коллекции.
     *
     * @return строка с описанием типа, даты и размера
     */
    public synchronized String getInfo() {
        return String.format("Тип: %s\nДата инициализации: %s\nКоличество элементов: %d",
                collection.getClass().getSimpleName(), initializationDate, collection.size());
    }

    /**
     * Получить всю коллекцию в строковом формате.
     *
     * @return string.
     */
    public synchronized String getAllString() {
        final ArrayList<LabWork> labWorks = new ArrayList<>(collection);
        final StringBuilder stringBuilder = new StringBuilder();
        for (LabWork labWork : labWorks) {
            stringBuilder.append(labWork).append("\n");
        }
        return stringBuilder.toString();
    }

    /**
     * Возвращает все элементы коллекции.
     *
     * @return список всех элементов
     */
    public synchronized Collection<LabWork> getAll() {
        return new ArrayList<>(collection);
    }

    /**
     * Проверяет наличие элемента с заданным id.
     *
     * @param id идентификатор
     * @return true, если элемент существует
     */
    public synchronized boolean existsById(Integer id) {
        return collection.stream().anyMatch(l -> l.getId() == id);
    }

    /**
     * Проверяет наличие элемента с заданным id и owner.
     *
     * @param id id
     * @param owner владелец.
     * @return boolean
     */
    public synchronized boolean checkOwner(Integer id, String owner) {
        return collection.stream().anyMatch(l -> {
            if (l.getId() != id) {
                return false;
            }
            return l.getOwner().equals(owner);
        });
    }

    /**
     * Удаляет из коллекции все элементы, превышающие заданный.
     *
     * @param labWork элемент для сравнения
     * @param owner владелец
     * @return количество удаленных элементов
     */
    public synchronized int removeGreater(LabWork labWork, String owner) {
        int count = 0;
        collection.removeIf(l -> {
            if (l.compareTo(labWork) <= 0) {
                return false;
            }
            return owner.equals(l.getOwner());
        });
        return count;
    }

    /**
     * Удаляет из коллекции все элементы, меньшие, чем заданный.
     *
     * @param labWork элемент для сравнения
     * @param owner владелец
     * @return количество удаленных элементов
     */
    public synchronized int removeLower(LabWork labWork, String owner) {
        int count = 0;
        collection.removeIf(l -> {
            if (l.compareTo(labWork) >= 0) {
                return false;
            }
            return owner.equals(l.getOwner());
        });
        return count;
    }


}
