package itmo.programming.server.commands;

import itmo.programming.common.network.Request;
import itmo.programming.common.network.Response;
import itmo.programming.server.manager.CollectionManager;

/**
 * Команда подсчета среднего значения поля averagePoint.
 */
public class AverageOfAveragePointCommand implements Command {
    private final CollectionManager collectionManager;

    /**
     * Создает новую команду подсчета среднего значения averagePoint.
     *
     * @param collectionManager менеджер коллекции
     */
    public AverageOfAveragePointCommand(CollectionManager collectionManager) {
        this.collectionManager = collectionManager;
    }

    /**
     * Выполняет команду подсчета среднего значения поля averagePoint.
     *
     * @param request запрос на выполнение команды
     * @return ответ со средним значением поля averagePoint
     */
    @Override
    public Response execute(Request request) {
        final double average = collectionManager.averageOfAveragePoint();
        return Response.ok(
            "Среднее значение поля averagePoint: " + average,
            average, null,
            request.getClientId()
        );
    }

    @Override
    public String getDescription() {
        return "average_of_average_point : вывести среднее значение поля averagePoint для всех элементов коллекции";
    }
}