package itmo.programming.server.database;

import itmo.programming.common.model.LabWork;
import itmo.programming.common.model.Coordinates;
import itmo.programming.common.model.Discipline;
import itmo.programming.common.model.Difficulty;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.TreeSet;

/**
 * Класс обеспечивает взаимодействие с базой данных для реализации коллекции LabWork.
 */
public class LabWorkDaO {
    private static final int ONE = 1;
    private static final int TWO = 2;
    private static final int THREE = 3;
    private static final int FOUR = 4;
    private static final int FIVE = 5;
    private static final int SIX = 6;
    private static final int SEVEN = 7;
    private static final int EIGHT = 8;
    private final Connection connection;

    /**
     * Конструктор.
     *
     * @param connection connection.
     */
    public LabWorkDaO(final Connection connection) {
        this.connection = connection;
    }

    /**
     * Загрузить все элементы коллекции из базы данных.
     *
     * @return treeset
     */
    public TreeSet<LabWork> loadAll() {
        final TreeSet<LabWork> collection = new TreeSet<>();
        final String sql = """
            SELECT
                l.*,
                c.x,
                c.y,
                d.name as discipline_name,
                d.lecture_hours
            FROM labwork l
            LEFT JOIN coordinates c ON l.coordinates_id = c.id
            LEFT JOIN discipline d ON l.discipline_id = d.id
            """;

        try (PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                final LabWork labWork = buildLabWorkFromResultSet(resultSet);
                collection.add(labWork);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Ошибка при загрузке коллекции из базы данных", e);
        }

        return collection;
    }

    /**
     * Вставить новый элемент в базу данных.
     *
     * @param labWork элемент для вставки
     * @param owner владелец элемента
     * @return сгенерированный ID
     * @throws SQLException исключение SQL
     */
    public int insert(LabWork labWork, String owner) throws SQLException {
        System.out.println("=== НАЧАЛО INSERT ===");
        System.out.println("Пользователь: " + owner);
        System.out.println("LabWork: " + labWork.getName());
        System.out.println("Autocommit: " + connection.getAutoCommit());
        
        // Проверяем существование пользователя
        if (!userExists(owner)) {
            throw new SQLException("Пользователь '" + owner + "' не существует в базе данных");
        }
        
        // Сначала вставляем coordinates
        final int coordinatesId = insertCoordinates(labWork.getCoordinates());
        System.out.println("Coordinates ID: " + coordinatesId);
        
        // Затем вставляем discipline
        final int disciplineId = insertDiscipline(labWork.getDiscipline());
        System.out.println("Discipline ID: " + disciplineId);
        
        // Наконец вставляем labwork
        final String sql = """
            INSERT INTO labwork (name, creation_date, minimal_point, average_point, 
                               difficulty, owner, coordinates_id, discipline_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """;

        System.out.println("SQL: " + sql);
        System.out.println("Параметры: name=" + labWork.getName() + 
                          ", owner=" + owner + 
                          ", coordinates_id=" + coordinatesId + 
                          ", discipline_id=" + disciplineId);

        try (PreparedStatement statement = connection.prepareStatement(sql, 
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setString(ONE, labWork.getName());
            statement.setDate(TWO, java.sql.Date.valueOf(labWork.getCreationDate()));
            statement.setInt(THREE, labWork.getMinimalPoint());
            statement.setDouble(FOUR, labWork.getAveragePoint());
            statement.setString(FIVE, labWork.getDifficulty() != null ? 
                labWork.getDifficulty().name() : null);
            statement.setString(SIX, owner);
            statement.setInt(SEVEN, coordinatesId);
            statement.setInt(EIGHT, disciplineId);

            System.out.println("Выполняем INSERT в labwork...");
            int rowsAffected = statement.executeUpdate();
            System.out.println("Строк затронуто: " + rowsAffected);

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    int generatedId = generatedKeys.getInt(1);
                    System.out.println("Сгенерированный ID: " + generatedId);
                    System.out.println("=== КОНЕЦ INSERT ===");
                    return generatedId;
                } else {
                    System.out.println("ОШИБКА: Не удалось получить сгенерированный ID");
                    throw new SQLException("Не удалось получить сгенерированный ID");
                }
            }
        } catch (SQLException e) {
            System.out.println("ОШИБКА SQL: " + e.getMessage());
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Обновить элемент в базе данных.
     *
     * @param id ID элемента
     * @param labWork новые данные
     * @param owner владелец элемента
     * @return true если обновление успешно
     * @throws SQLException исключение SQL
     */
    public boolean update(int id, LabWork labWork, String owner) throws SQLException {
        // Получаем старые IDs
        final String getIdsSql = """
            SELECT coordinates_id, discipline_id FROM labwork WHERE id = ? AND owner = ?
            """;
        
        Integer oldCoordinatesId = null;
        Integer oldDisciplineId = null;
        
        try (PreparedStatement statement = connection.prepareStatement(getIdsSql)) {
            statement.setInt(ONE, id);
            statement.setString(TWO, owner);
            final ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                oldCoordinatesId = rs.getObject("coordinates_id", Integer.class);
                oldDisciplineId = rs.getObject("discipline_id", Integer.class);
            } else {
                return false; // Запись не найдена
            }
        }

        // Обновляем coordinates
        if (oldCoordinatesId != null) {
            updateCoordinates(oldCoordinatesId, labWork.getCoordinates());
        } else {
            insertCoordinates(labWork.getCoordinates());
        }

        // Обновляем discipline
        if (oldDisciplineId != null) {
            updateDiscipline(oldDisciplineId, labWork.getDiscipline());
        } else {
            insertDiscipline(labWork.getDiscipline());
        }

        // Обновляем labwork
        final String updateSql = """
            UPDATE labwork 
            SET name = ?, creation_date = ?, minimal_point = ?, average_point = ?, 
                difficulty = ?
            WHERE id = ? AND owner = ?
            """;

        try (PreparedStatement statement = connection.prepareStatement(updateSql)) {
            statement.setString(ONE, labWork.getName());
            statement.setDate(TWO, java.sql.Date.valueOf(labWork.getCreationDate()));
            statement.setInt(THREE, labWork.getMinimalPoint());
            statement.setDouble(FOUR, labWork.getAveragePoint());
            statement.setString(FIVE, labWork.getDifficulty() != null ? 
                labWork.getDifficulty().name() : null);
            statement.setInt(SIX, id);
            statement.setString(SEVEN, owner);

            return statement.executeUpdate() > 0;
        }
    }

    /**
     * Удалить элемент по ID.
     *
     * @param id ID элемента
     * @param owner владелец элемента
     * @return true если удаление успешно
     * @throws SQLException исключение SQL
     */
    public boolean deleteById(int id, String owner) throws SQLException {
        final String getIdsSql = """
            SELECT coordinates_id, discipline_id FROM labwork WHERE id = ? AND owner = ?
            """;
        final String deleteLabWorkSql = "DELETE FROM labwork WHERE id = ? AND owner = ?";
        final String deleteCoordinatesSql = "DELETE FROM coordinates WHERE id = ?";
        final String deleteDisciplineSql = "DELETE FROM discipline WHERE id = ?";

        try {
            Integer coordinatesId = null;
            Integer disciplineId = null;

            // Получаем IDs перед удалением
            try (PreparedStatement statement = connection.prepareStatement(getIdsSql)) {
                statement.setInt(ONE, id);
                statement.setString(TWO, owner);
                final ResultSet rs = statement.executeQuery();
                if (rs.next()) {
                    coordinatesId = rs.getObject("coordinates_id", Integer.class);
                    disciplineId = rs.getObject("discipline_id", Integer.class);
                } else {
                    return false; // Запись не найдена
                }
            }
            
            try (PreparedStatement statement = connection.prepareStatement(deleteLabWorkSql)) {
                statement.setInt(ONE, id);
                statement.setString(TWO, owner);
                if (statement.executeUpdate() == 0) {
                    return false;
                }
            }
            
            if (coordinatesId != null) {
                try (PreparedStatement statement = connection.prepareStatement(deleteCoordinatesSql)) {
                    statement.setInt(ONE, coordinatesId);
                    statement.executeUpdate();
                }
            }
            
            if (disciplineId != null) {
                try (PreparedStatement statement = connection.prepareStatement(deleteDisciplineSql)) {
                    statement.setInt(ONE, disciplineId);
                    statement.executeUpdate();
                }
            }
            
            return true;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Удалить все элементы пользователя.
     *
     * @param owner владелец элементов
     * @return true если удаление успешно
     * @throws SQLException исключение SQL
     */
    public boolean deleteAll(String owner) throws SQLException {
        final String getIdsSql = """
            SELECT coordinates_id, discipline_id 
            FROM labwork 
            WHERE owner = ?
            """;

        final String deleteLabWorkSql = """
            DELETE FROM labwork 
            WHERE owner = ?
            """;

        final String checkCoordinatesUsage = """
            SELECT COUNT(*) 
            FROM labwork 
            WHERE coordinates_id = ?
            """;

        final String deleteCoordinatesSql = """
            DELETE FROM coordinates 
            WHERE id = ?
            """;

        final String checkDisciplineUsage = """
            SELECT COUNT(*) 
            FROM labwork 
            WHERE discipline_id = ?
            """;

        final String deleteDisciplineSql = """
            DELETE FROM discipline 
            WHERE id = ?
            """;

        try {
            final TreeSet<Integer> coordinateIds = new TreeSet<>();
            final TreeSet<Integer> disciplineIds = new TreeSet<>();

            try (PreparedStatement statement = connection.prepareStatement(getIdsSql)) {
                statement.setString(ONE, owner);
                final ResultSet rs = statement.executeQuery();
                while (rs.next()) {
                    final Integer coordId = rs.getObject("coordinates_id", Integer.class);
                    final Integer discId = rs.getObject("discipline_id", Integer.class);
                    if (coordId != null) {
                        coordinateIds.add(coordId);
                    }
                    if (discId != null) {
                        disciplineIds.add(discId);
                    }
                }
            }

            try (PreparedStatement statement = connection.prepareStatement(deleteLabWorkSql)) {
                statement.setString(ONE, owner);
                final int rowsDeleted = statement.executeUpdate();
                if (rowsDeleted == 0) {
                    return false;
                }
            }

            // Удаляем неиспользуемые coordinates
            for (Integer id : coordinateIds) {
                try (PreparedStatement statement = connection.prepareStatement(checkCoordinatesUsage)) {
                    statement.setInt(ONE, id);
                    final ResultSet rs = statement.executeQuery();
                    rs.next();
                    if (rs.getInt(ONE) == 0) {
                        try (PreparedStatement delStmt = connection.prepareStatement(deleteCoordinatesSql)) {
                            delStmt.setInt(ONE, id);
                            delStmt.executeUpdate();
                        }
                    }
                }
            }

            // Удаляем неиспользуемые disciplines
            for (Integer id : disciplineIds) {
                try (PreparedStatement statement = connection.prepareStatement(checkDisciplineUsage)) {
                    statement.setInt(ONE, id);
                    final ResultSet rs = statement.executeQuery();
                    rs.next();
                    if (rs.getInt(ONE) == 0) {
                        try (PreparedStatement delStmt = connection.prepareStatement(deleteDisciplineSql)) {
                            delStmt.setInt(ONE, id);
                            delStmt.executeUpdate();
                        }
                    }
                }
            }

            return true;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /**
     * Вставить coordinates в базу данных.
     */
    private int insertCoordinates(Coordinates coordinates) throws SQLException {
        final String sql = "INSERT INTO coordinates (x, y) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql, 
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setLong(ONE, coordinates.getX());
            statement.setLong(TWO, coordinates.getY());
            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(ONE);
                } else {
                    throw new SQLException("Не удалось получить ID coordinates");
                }
            }
        }
    }

    /**
     * Вставить discipline в базу данных.
     */
    private int insertDiscipline(Discipline discipline) throws SQLException {
        final String sql = "INSERT INTO discipline (name, lecture_hours) VALUES (?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql, 
                PreparedStatement.RETURN_GENERATED_KEYS)) {
            statement.setString(ONE, discipline.getName());
            statement.setInt(TWO, discipline.getLectureHours());
            statement.executeUpdate();

            try (ResultSet generatedKeys = statement.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    return generatedKeys.getInt(ONE);
                } else {
                    throw new SQLException("Не удалось получить ID discipline");
                }
            }
        }
    }

    /**
     * Обновить coordinates в базе данных.
     */
    private void updateCoordinates(int id, Coordinates coordinates) throws SQLException {
        final String sql = "UPDATE coordinates SET x = ?, y = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setLong(ONE, coordinates.getX());
            statement.setLong(TWO, coordinates.getY());
            statement.setInt(THREE, id);
            statement.executeUpdate();
        }
    }

    /**
     * Обновить discipline в базе данных.
     */
    private void updateDiscipline(int id, Discipline discipline) throws SQLException {
        final String sql = "UPDATE discipline SET name = ?, lecture_hours = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(ONE, discipline.getName());
            statement.setInt(TWO, discipline.getLectureHours());
            statement.setInt(THREE, id);
            statement.executeUpdate();
        }
    }

    /**
     * Построить LabWork из ResultSet.
     */
    private LabWork buildLabWorkFromResultSet(ResultSet resultSet) throws SQLException {
        final int id = resultSet.getInt("id");
        final String name = resultSet.getString("name");
        final LocalDate creationDate = resultSet.getDate("creation_date").toLocalDate();
        final int minimalPoint = resultSet.getInt("minimal_point");
        final double averagePoint = resultSet.getDouble("average_point");
        final String difficultyStr = resultSet.getString("difficulty");
        final String owner = resultSet.getString("owner");

        // Создаем Coordinates
        final Long x = resultSet.getObject("x", Long.class);
        final Long y = resultSet.getObject("y", Long.class);
        final Coordinates coordinates = new Coordinates(x, y);

        // Создаем Discipline
        final String disciplineName = resultSet.getString("discipline_name");
        final int lectureHours = resultSet.getInt("lecture_hours");
        final Discipline discipline = new Discipline(disciplineName, lectureHours);

        // Создаем Difficulty
        Difficulty difficulty = null;
        if (difficultyStr != null) {
            try {
                difficulty = Difficulty.valueOf(difficultyStr);
            } catch (IllegalArgumentException e) {
                // Игнорируем неверные значения
            }
        }

        final LabWork labWork = new LabWork(id, name, coordinates, creationDate, 
                minimalPoint, averagePoint, difficulty, discipline);
        labWork.setOwner(owner);

        return labWork;
    }

    /**
     * Проверяет, существует ли пользователь в базе данных.
     *
     * @param username имя пользователя
     * @return true если пользователь существует
     */
    private boolean userExists(String username) {
        final String sql = "SELECT 1 FROM users WHERE username = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(ONE, username);
            final ResultSet rs = statement.executeQuery();
            return rs.next();
        } catch (SQLException e) {
            return false;
        }
    }
}
