package itmo.programming.server.commands;

import itmo.programming.common.model.LabWork;
import itmo.programming.common.network.Request;
import itmo.programming.common.network.Response;
import itmo.programming.server.database.LabWorkDaO;
import itmo.programming.server.manager.CollectionManager;
import java.sql.SQLException;

/**
 * Команда удаления элементов, превышающих заданный.
 */
public class RemoveGreaterCommand implements Command {
    private final CollectionManager collectionManager;
    private final LabWorkDaO labWorkDaO;

    /**
     * Создает новую команду удаления больших элементов.
     *
     * @param collectionManager менеджер коллекции
     * @param collectionDaO DAO для работы с базой данных
     */
    public RemoveGreaterCommand(CollectionManager collectionManager, LabWorkDaO labWorkDaO) {
        this.collectionManager = collectionManager;
        this.labWorkDaO = labWorkDaO;
    }

    /**
     * Выполняет команду удаления элементов, превышающих заданный.
     *
     * @param request запрос, содержащий элемент для сравнения
     * @return ответ с результатом выполнения команды
     */
    @Override
    public Response execute(Request request) {
        try {
            final LabWork labWork = (LabWork) request.getData();
            final String username = request.getUser().getUsername();
            
            if (labWork == null) {
                return Response.error("Невозможно удалить элементы по пустому объекту!",
                        null, null, request.getClientId());
            }

            // Получаем все элементы пользователя, которые больше заданного
            final var userElements = collectionManager.getCollection().stream()
                    .filter(l -> {
                        if (!username.equals(l.getOwner())) {
                            return false;
                        }
                        return l.compareTo(labWork) > 0;
                    })
                    .toList();

            int removedCount = 0;
            for (LabWork element : userElements) {
                if (labWorkDaO.deleteById(element.getId(), username)) {
                    synchronized (collectionManager) {
                        collectionManager.removeById(element.getId(), username);
                    }
                    removedCount++;
                }
            }

            return Response.ok("Удалено элементов: " + removedCount,
                    removedCount, null, request.getClientId());
        } catch (SQLException e) {
            return Response.error("Ошибка при удалении элементов",
                    null, null, request.getClientId());
        }
    }

    @Override
    public String getDescription() {
        return "remove_greater {element} : удалить из коллекции все элементы, превышающие заданный";
    }
}
