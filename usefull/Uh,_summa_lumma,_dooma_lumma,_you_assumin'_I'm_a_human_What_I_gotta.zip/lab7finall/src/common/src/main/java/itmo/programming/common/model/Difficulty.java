package itmo.programming.common.model;

/**
 * Перечисление уровней сложности лабораторной работы.
 */
public enum Difficulty {
    EASY,
    INSANE,
    TERRIBLE;

    /**
     * Получить все доступные уровни сложности.
     *
     * @return массив всех уровней сложности
     */
    public static Difficulty[] getAllDifficulties() {
        return values();
    }
}
