package itmo.programming.common.model;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.Comparator;
import java.util.Objects;

/**
 * Класс, представляющий лабораторную работу.
 */
public class LabWork implements Comparable<LabWork>, Serializable {

    private int id; // Значение поля должно быть больше 0, Значение этого поля должно быть уникальным, 
                   // Значение этого поля должно генерироваться автоматически
    private String name; // Поле не может быть null, Строка не может быть пустой
    private Coordinates coordinates; // Поле не может быть null
    private LocalDate creationDate; // Поле не может быть null, Значение этого поля должно генерироваться автоматически
    private int minimalPoint; // Значение поля должно быть больше 0
    private double averagePoint; // Значение поля должно быть больше 0
    private Difficulty difficulty; // Поле может быть null
    private Discipline discipline; // Поле не может быть null
    private String owner; // имя пользователя — нужно для контроля прав доступа

    /**
     * Пустой конструктор для GSON.
     */
    public LabWork() {
    }

    /**
     * Конструктор для создания лабораторной работы.
     *
     * @param id идентификатор
     * @param name название
     * @param coordinates координаты
     * @param creationDate дата создания
     * @param minimalPoint минимальный балл
     * @param averagePoint средний балл
     * @param difficulty сложность
     * @param discipline дисциплина
     */
    public LabWork(int id, String name, Coordinates coordinates,
            LocalDate creationDate, int minimalPoint, double averagePoint,
            Difficulty difficulty, Discipline discipline) {
        this.id = id;
        this.name = name;
        this.coordinates = coordinates;
        this.creationDate = creationDate != null ? creationDate : LocalDate.now();
        this.minimalPoint = minimalPoint;
        this.averagePoint = averagePoint;
        this.difficulty = difficulty;
        this.discipline = discipline;
        this.owner = null;
    }

    /**
     * Получить username владельца элемента.
     *
     * @return username.
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Присвоить владельца элементу.
     *
     * @param owner username владельца.
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }

    /**
     * Получить идентификатор.
     *
     * @return идентификатор
     */
    public int getId() {
        return id;
    }

    /**
     * Установить идентификатор.
     *
     * @param id идентификатор
     */
    public void setId(int id) {
        this.id = id;
    }

    /**
     * Получить название.
     *
     * @return название
     */
    public String getName() {
        return name;
    }

    /**
     * Установить название.
     *
     * @param name название
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Получить координаты.
     *
     * @return координаты
     */
    public Coordinates getCoordinates() {
        return coordinates;
    }

    /**
     * Установить координаты.
     *
     * @param coordinates координаты
     */
    public void setCoordinates(Coordinates coordinates) {
        this.coordinates = coordinates;
    }

    /**
     * Получить дату создания.
     *
     * @return дата создания
     */
    public LocalDate getCreationDate() {
        return creationDate;
    }

    /**
     * Установить дату создания.
     *
     * @param creationDate дата создания
     */
    public void setCreationDate(LocalDate creationDate) {
        this.creationDate = creationDate;
    }

    /**
     * Получить минимальный балл.
     *
     * @return минимальный балл
     */
    public int getMinimalPoint() {
        return minimalPoint;
    }

    /**
     * Установить минимальный балл.
     *
     * @param minimalPoint минимальный балл
     */
    public void setMinimalPoint(int minimalPoint) {
        this.minimalPoint = minimalPoint;
    }

    /**
     * Получить средний балл.
     *
     * @return средний балл
     */
    public double getAveragePoint() {
        return averagePoint;
    }

    /**
     * Установить средний балл.
     *
     * @param averagePoint средний балл
     */
    public void setAveragePoint(double averagePoint) {
        this.averagePoint = averagePoint;
    }

    /**
     * Получить сложность.
     *
     * @return сложность
     */
    public Difficulty getDifficulty() {
        return difficulty;
    }

    /**
     * Установить сложность.
     *
     * @param difficulty сложность
     */
    public void setDifficulty(Difficulty difficulty) {
        this.difficulty = difficulty;
    }

    /**
     * Получить дисциплину.
     *
     * @return дисциплина
     */
    public Discipline getDiscipline() {
        return discipline;
    }

    /**
     * Установить дисциплину.
     *
     * @param discipline дисциплина
     */
    public void setDiscipline(Discipline discipline) {
        this.discipline = discipline;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final LabWork that = (LabWork) o;
        
        // Сравниваем по всем полям, кроме id
        if (minimalPoint != that.minimalPoint) {
            return false;
        }
        if (Double.compare(that.averagePoint, averagePoint) != 0) {
            return false;
        }
        if (!Objects.equals(name, that.name)) {
            return false;
        }
        if (!Objects.equals(coordinates, that.coordinates)) {
            return false;
        }
        if (!Objects.equals(creationDate, that.creationDate)) {
            return false;
        }
        if (difficulty != that.difficulty) {
            return false;
        }
        if (!Objects.equals(discipline, that.discipline)) {
            return false;
        }
        return Objects.equals(owner, that.owner);
    }

    @Override
    public int hashCode() {
        // Генерируем хеш-код по всем полям, кроме id
        return Objects.hash(name, coordinates, creationDate, minimalPoint,
                averagePoint, difficulty, discipline, owner);
    }

    @Override
    public String toString() {
        return "LabWork{"
                + "id=" + id
                + ", name='" + name + '\''
                + ", coordinates=" + coordinates
                + ", creationDate=" + creationDate
                + ", minimalPoint=" + minimalPoint
                + ", averagePoint=" + averagePoint
                + ", difficulty=" + difficulty
                + ", discipline=" + discipline
                + ", owner=" + owner
                + '}';
    }

    @Override
    public int compareTo(LabWork o) {
        if (o == null) {
            return 1;
        }
        return Comparator
                .comparing(LabWork::getName, Comparator.nullsFirst(String::compareTo))
                .thenComparing(LabWork::getId, Comparator.nullsFirst(Integer::compareTo))
                .compare(this, o);
    }
}
