package itmo.programming.common.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Класс координат, представляющий точку в двумерном пространстве.
 */
public class Coordinates implements Comparable<Coordinates>, Serializable {

    private Long x; // Максимальное значение поля: 677, Поле не может быть null
    private Long y; // Поле не может быть null

    /**
     * Пустой конструктор для GSON.
     */
    public Coordinates() {
    }

    /**
     * Конструктор для создания координат.
     *
     * @param x координата X
     * @param y координата Y
     */
    public Coordinates(Long x, Long y) {
        this.x = x;
        this.y = y;
    }

    /**
     * Вычисляет расстояние от начала координат до точки.
     *
     * @return расстояние от начала координат
     */
    public double distance() {
        return Math.sqrt(x * x + y * y);
    }

    /**
     * Получить координату X.
     *
     * @return координата X
     */
    public Long getX() {
        return x;
    }

    /**
     * Установить координату X.
     *
     * @param x координата X
     */
    public void setX(Long x) {
        this.x = x;
    }

    /**
     * Получить координату Y.
     *
     * @return координата Y
     */
    public Long getY() {
        return y;
    }

    /**
     * Установить координату Y.
     *
     * @param y координата Y
     */
    public void setY(Long y) {
        this.y = y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final Coordinates that = (Coordinates) o;
        if (!Objects.equals(x, that.x)) {
            return false;
        }
        return Objects.equals(y, that.y);
    }

    @Override
    public int hashCode() {
        return Objects.hash(x, y);
    }

    @Override
    public String toString() {
        return "Coordinates{"
                + "x=" + x
                + ", y=" + y
                + '}';
    }

    @Override
    public int compareTo(Coordinates o) {
        return Double.compare(distance(), o.distance());
    }
}
