package itmo.programming.common.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Класс, представляющий дисциплину.
 */
public class Discipline implements Serializable {
    
    private String name; // Поле не может быть null, Строка не может быть пустой
    private int lectureHours;

    /**
     * Пустой конструктор для GSON.
     */
    public Discipline() {
    }

    /**
     * Конструктор для создания дисциплины.
     *
     * @param name название дисциплины
     * @param lectureHours количество часов лекций
     */
    public Discipline(String name, int lectureHours) {
        this.name = name;
        this.lectureHours = lectureHours;
    }

    /**
     * Получить название дисциплины.
     *
     * @return название дисциплины
     */
    public String getName() {
        return name;
    }

    /**
     * Установить название дисциплины.
     *
     * @param name название дисциплины
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Получить количество часов лекций.
     *
     * @return количество часов лекций
     */
    public int getLectureHours() {
        return lectureHours;
    }

    /**
     * Установить количество часов лекций.
     *
     * @param lectureHours количество часов лекций
     */
    public void setLectureHours(int lectureHours) {
        this.lectureHours = lectureHours;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final Discipline that = (Discipline) o;
        if (lectureHours != that.lectureHours) {
            return false;
        }
        return Objects.equals(name, that.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, lectureHours);
    }

    @Override
    public String toString() {
        return "Discipline{"
                + "name='" + name + '\''
                + ", lectureHours=" + lectureHours
                + '}';
    }
}
