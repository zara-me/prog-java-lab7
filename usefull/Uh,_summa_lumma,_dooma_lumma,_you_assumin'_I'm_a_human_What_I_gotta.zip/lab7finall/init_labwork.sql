-- SQL запросы для создания таблиц на основе классов LabWork, Coordinates, Discipline и enum Difficulty

-- Создание таблицы пользователей
CREATE TABLE IF NOT EXISTS users (
    username VARCHAR(255) PRIMARY KEY,
    password_hash VARCHAR(255) NOT NULL,
    salt VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
);

-- Убираем enum, используем обычную строку для difficulty

-- Создание таблицы Coordinates
CREATE TABLE IF NOT EXISTS coordinates (
    id SERIAL PRIMARY KEY,
    x BIGINT NOT NULL CHECK (x <= 677),
    y BIGINT NOT NULL
);

-- Создание таблицы Discipline
CREATE TABLE IF NOT EXISTS discipline (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL CHECK (LENGTH(TRIM(name)) > 0),
    lecture_hours INTEGER NOT NULL
);

-- Создание последовательности для автоматической генерации ID LabWork
CREATE SEQUENCE IF NOT EXISTS labwork_id_seq START 1;

-- Создание таблицы LabWork (сначала без внешнего ключа на users)
CREATE TABLE IF NOT EXISTS labwork (
    id INTEGER PRIMARY KEY DEFAULT nextval('labwork_id_seq'),
    name VARCHAR(255) NOT NULL CHECK (LENGTH(TRIM(name)) > 0),
    coordinates_id INTEGER NOT NULL REFERENCES coordinates(id) ON DELETE CASCADE,
    creation_date DATE NOT NULL DEFAULT CURRENT_DATE,
    minimal_point INTEGER NOT NULL CHECK (minimal_point > 0),
    average_point DOUBLE PRECISION NOT NULL CHECK (average_point > 0),
    difficulty VARCHAR(20),
    discipline_id INTEGER NOT NULL REFERENCES discipline(id) ON DELETE CASCADE,
    owner VARCHAR(255) NOT NULL
);

-- Добавляем внешний ключ для owner
DO $$ 
BEGIN
    -- Проверяем, существует ли уже ограничение
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.table_constraints 
        WHERE table_name = 'labwork' 
        AND constraint_name = 'fk_labwork_owner'
    ) THEN
        ALTER TABLE labwork 
        ADD CONSTRAINT fk_labwork_owner 
        FOREIGN KEY (owner) REFERENCES users(username) ON DELETE CASCADE;
    END IF;
END $$;

